//definine a classe principal da aplicação para a pagina inicial.
class PadariaApp{
    //o construtor é chamado quando uma nova instancia de classe é criada.
    constructor(){
        thiis.categoriner = document.getElementByUd('lista-categoria');
        //chama o metodo init() para iniciar a aplicação
        this.init();
    }
    //Método de inicialização da aplicação
async init() {
    try{
        //Tenta busca as categoras da API.
        const categorias = await this.fetchCategorias();
        //Se a busca for bem-sucedida, redenriza as categorias na página
        this.renderCategorias(categorias);
        }catch (error) {
        //se ocorre um rero na busca, exibe uma mensagem de erro no console e na pagina
        console.error('Erro ao inicializar a aplicação:', error);
        this.categoriasContainer.innerHTML = '<p> Erro ao carregar categorias.</p>';

        }
    }
    //metodo assincrono para buscar as categorias dos produtos na API.
    async fetchCategorias(){
        //faz uma requisição GET para a API de produtos, pedidos em limite alto para garantir que as categorias seja representadas.
        const response = await fetch('/api/produtos?limit=1000');
        //Verifica se a resposta da requisição doi bem-sucedida.
        if (!response.ok) {
        //Se não for, lança um erro.
        throw new Error('Erro ao buscar produtos');
        }
        //Converte a resposa da API de JSON para um objeto JavaScript.
        const result = await response.json();
        //extrai as categorias de todos os produtos
        //"map" cria um novo array
        //"new Set" remove as duplicatas
        //"..." converte o Set de volta para array
        const categorias = [...new Set(result.data.map( p => p.categoria))];
        //retorna o array de categorias.
        return categorias;
    }

    //
    renderCategorias(categorias){
        //
        this.categoriasContainer.innerHTML = categorias.map(categoria =>`
            <a href="produtos.html?categoria=${categoria}"class="category-card">
            <h3>${categoria}<h3>
            </a>
            `).join('');//join junta todos elementos em uma unica string de HTML
    }
}
//cria um nova instância da classe PadariaApp que inicia todo o processo.
new PadariaApp();